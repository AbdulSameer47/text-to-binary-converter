package com.example.converter
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import android.net.Uri
import java.lang.StringBuilder

object BinaryConverter{

    fun strToBinary(str:String):String{
        val builder = StringBuilder()

        for (c in str.toCharArray()){
            val toString = Integer.toString(c.toInt(),2);
            builder.append(String.format("%08d",Integer.parseInt(toString)));
        }

        return builder.toString()
    }




}